/* CineVerse — movie discovery demo. Uses TMDB only when a key is configured. */
"use strict";

const TMDB_KEY = ""; // Optional: add a TMDB v3 API key for local testing. Do not commit private credentials.
const API_BASE = "https://api.themoviedb.org/3";
const IMAGE_BASE = "https://image.tmdb.org/t/p/w500";
const BACKDROP_BASE = "https://image.tmdb.org/t/p/w1280";
const LANGUAGES = [
  ["te","Telugu"],["ta","Tamil"],["hi","Hindi"],["ml","Malayalam"],["kn","Kannada"],
  ["bn","Bengali"],["mr","Marathi"],["pa","Punjabi"],["gu","Gujarati"],["or","Odia"],
  ["as","Assamese"],["en","English"],["ko","Korean"],["ja","Japanese"],["zh","Chinese"],
  ["es","Spanish"],["fr","French"],["de","German"],["it","Italian"],["pt","Portuguese"],
  ["tr","Turkish"],["th","Thai"],["id","Indonesian"],["ar","Arabic"],["ru","Russian"],
  ["fa","Persian"],["sv","Swedish"],["da","Danish"],["no","Norwegian"],["pl","Polish"],
  ["nl","Dutch"],["fi","Finnish"],["uk","Ukrainian"],["el","Greek"],["he","Hebrew"],
  ["vi","Vietnamese"],["hu","Hungarian"],["cs","Czech"],["ro","Romanian"],["other","Other"]
];
const GENRES = [
  {id:28,name:"Action"},{id:12,name:"Adventure"},{id:16,name:"Animation"},{id:35,name:"Comedy"},
  {id:80,name:"Crime"},{id:99,name:"Documentary"},{id:18,name:"Drama"},{id:10751,name:"Family"},
  {id:14,name:"Fantasy"},{id:36,name:"History"},{id:27,name:"Horror"},{id:10402,name:"Music"},
  {id:9648,name:"Mystery"},{id:10749,name:"Romance"},{id:878,name:"Science Fiction"},
  {id:10770,name:"TV Movie"},{id:53,name:"Thriller"},{id:10752,name:"War"},{id:37,name:"Western"}
];
const DEMO_MOVIES = [
  {id:900001,title:"The Grand Journey",original_title:"The Grand Journey",original_language:"en",release_date:"2024-06-14",vote_average:7.8,popularity:98,overview:"A mapmaker and a restless traveller cross continents to uncover a forgotten story about courage, friendship, and the meaning of home.",genre_ids:[12,18],poster_path:null,backdrop_path:null},
  {id:900002,title:"Chandamama Stories",original_title:"Chandamama Stories",original_language:"te",release_date:"2023-10-20",vote_average:8.1,popularity:91,overview:"A close-knit family discovers that the smallest village traditions can hold the biggest lessons about love, belonging, and hope.",genre_ids:[18,10751],poster_path:null,backdrop_path:null},
  {id:900003,title:"The Last Monsoon",original_title:"The Last Monsoon",original_language:"ta",release_date:"2022-08-12",vote_average:7.6,popularity:89,overview:"When an unexpected storm changes a coastal town, a young photographer reconnects with the people and places she thought she had left behind.",genre_ids:[18,10749],poster_path:null,backdrop_path:null},
  {id:900004,title:"Paper Lanterns",original_title:"Paper Lanterns",original_language:"ja",release_date:"2024-02-02",vote_average:8.3,popularity:87,overview:"Two neighbours leave handwritten wishes in a lantern shop, slowly learning how their quiet hopes connect across generations.",genre_ids:[18,10749],poster_path:null,backdrop_path:null},
  {id:900005,title:"Midnight Seoul",original_title:"Midnight Seoul",original_language:"ko",release_date:"2023-11-03",vote_average:7.9,popularity:85,overview:"A night-shift taxi driver becomes an unlikely guide to strangers whose lives intersect during one unforgettable night in the city.",genre_ids:[18,53],poster_path:null,backdrop_path:null},
  {id:900006,title:"Nila's Promise",original_title:"Nila's Promise",original_language:"ml",release_date:"2021-12-17",vote_average:8.0,popularity:83,overview:"A determined teacher returns to her riverside hometown and starts a reading club that brings an entire community together.",genre_ids:[18,10751],poster_path:null,backdrop_path:null},
  {id:900007,title:"City of Rain",original_title:"City of Rain",original_language:"hi",release_date:"2024-09-06",vote_average:7.4,popularity:80,overview:"An ambitious young architect and a street musician find unexpected common ground while trying to save a neighbourhood cinema.",genre_ids:[18,10749],poster_path:null,backdrop_path:null},
  {id:900008,title:"The Blue Bicycle",original_title:"The Blue Bicycle",original_language:"fr",release_date:"2022-05-19",vote_average:7.7,popularity:78,overview:"A bicycle mechanic sets off across the countryside to return a lost camera, discovering a different kind of freedom along the way.",genre_ids:[12,35],poster_path:null,backdrop_path:null},
  {id:900009,title:"Red Earth",original_title:"Red Earth",original_language:"kn",release_date:"2023-04-21",vote_average:7.5,popularity:75,overview:"A young farmer experiments with sustainable methods to protect the land his family has cared for over three generations.",genre_ids:[18],poster_path:null,backdrop_path:null},
  {id:900010,title:"Beyond the Clouds",original_title:"Beyond the Clouds",original_language:"zh",release_date:"2023-07-07",vote_average:8.2,popularity:73,overview:"An astronomy student and her grandfather build a small observatory and rediscover a shared love of looking up at the night sky.",genre_ids:[18,878],poster_path:null,backdrop_path:null},
  {id:900011,title:"The Silent Harbour",original_title:"The Silent Harbour",original_language:"es",release_date:"2020-03-13",vote_average:7.2,popularity:70,overview:"A marine biologist returns to a harbour town to investigate unusual changes in the water and confront an old family mystery.",genre_ids:[9648,18],poster_path:null,backdrop_path:null},
  {id:900012,title:"A Little More Time",original_title:"A Little More Time",original_language:"it",release_date:"2024-01-26",vote_average:7.9,popularity:68,overview:"A clock repairer finds a collection of letters that helps a stranger reconnect with a family history almost forgotten.",genre_ids:[18,10749],poster_path:null,backdrop_path:null},
  {id:900013,title:"Desert Bloom",original_title:"Desert Bloom",original_language:"ar",release_date:"2021-09-10",vote_average:7.6,popularity:66,overview:"A young botanist searches for a rare desert flower and finds a community protecting a fragile ecosystem against the odds.",genre_ids:[12,18],poster_path:null,backdrop_path:null},
  {id:900014,title:"Northern Lights",original_title:"Northern Lights",original_language:"de",release_date:"2022-12-02",vote_average:7.8,popularity:64,overview:"Two estranged siblings travel north to fulfil their mother's last wish and learn to see each other with fresh eyes.",genre_ids:[18],poster_path:null,backdrop_path:null},
  {id:900015,title:"The Rhythm of Home",original_title:"The Rhythm of Home",original_language:"bn",release_date:"2023-02-10",vote_average:7.7,popularity:62,overview:"A percussionist returns to her family's music school and helps a group of students find their own voices.",genre_ids:[10402,18],poster_path:null,backdrop_path:null},
  {id:900016,title:"One More Summer",original_title:"One More Summer",original_language:"pt",release_date:"2020-07-24",vote_average:7.3,popularity:60,overview:"A seaside café becomes the meeting place for old friends, new beginnings, and a summer that changes their plans.",genre_ids:[35,10749],poster_path:null,backdrop_path:null}
];

const state = {
  view: "home", language: "", genre: "", year: "", rating: 0, sort: "popularity",
  search: "", page: 1, totalPages: 1, loading: false, apiMode: Boolean(TMDB_KEY),
  movies: [], filteredMovies: [], selectedMovie: null, requestId: 0,
  favorites: readStorage("cineverse-favorites", []), watchlist: readStorage("cineverse-watchlist", [])
};
const $ = (selector) => document.querySelector(selector);
const grid = $("#movie-grid");
const status = $("#status-message");
const modal = $("#movie-modal");
let toastTimer;

function readStorage(key, fallback) {
  try { const parsed = JSON.parse(localStorage.getItem(key)); return Array.isArray(parsed) ? parsed : fallback; }
  catch { return fallback; }
}
function saveStorage(key, value) {
  try { localStorage.setItem(key, JSON.stringify(value)); }
  catch { showToast("Storage is unavailable in this browser."); }
}
function escapeHtml(value = "") {
  return String(value).replace(/[&<>"']/g, char => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[char]));
}
function languageName(code) {
  return LANGUAGES.find(item => item[0] === code)?.[1] || (code ? code.toUpperCase() : "Unknown");
}
function genreNames(ids = []) {
  return ids.map(id => GENRES.find(g => g.id === id)?.name).filter(Boolean);
}
function yearOf(movie) { return movie.release_date ? movie.release_date.slice(0, 4) : "—"; }
function posterUrl(path) { return path ? (path.startsWith("http") ? path : IMAGE_BASE + path) : ""; }
function isFavorite(id) { return state.favorites.includes(Number(id)); }
function isWatchlisted(id) { return state.watchlist.includes(Number(id)); }

function initFilters() {
  const languageSelect = $("#language-filter");
  LANGUAGES.filter(item => item[0] !== "other").forEach(([code, name]) => {
    const option = document.createElement("option"); option.value = code; option.textContent = name; languageSelect.append(option);
  });
  GENRES.forEach(genre => {
    const option = document.createElement("option"); option.value = String(genre.id); option.textContent = genre.name; $("#genre-filter").append(option);
  });
  const currentYear = new Date().getFullYear();
  for (let year = currentYear + 1; year >= 1930; year--) {
    const option = document.createElement("option"); option.value = String(year); option.textContent = String(year); $("#year-filter").append(option);
  }
  $("#mode-label").textContent = state.apiMode ? "Live TMDB data" : "Demo mode";
}
function setStatus(message = "") { status.textContent = message; }
function showToast(message) {
  const toast = $("#toast"); toast.textContent = message; toast.classList.add("show");
  clearTimeout(toastTimer); toastTimer = setTimeout(() => toast.classList.remove("show"), 2200);
}
function syncFilterControls() {
  $("#language-filter").value = state.language;
  $("#genre-filter").value = state.genre;
  $("#year-filter").value = state.year;
  $("#rating-filter").value = String(state.rating);
  $("#sort-filter").value = state.sort;
  $("#search-input").value = state.search;
  $("#clear-search").hidden = !state.search;
  document.querySelectorAll(".language-chip").forEach(chip => chip.classList.toggle("selected", (chip.dataset.language || "") === state.language));
}
function setView(view) {
  state.view = view; state.page = 1;
  document.querySelectorAll(".nav-link").forEach(button => button.classList.toggle("active", button.dataset.view === view));
  const titles = {home:["Explore movies","A universe of stories, one movie at a time."],all:["All movies","Explore titles from every language and genre."],trending:["Trending now","See what's catching movie lovers' attention."],popular:["Popular movies","Discover movies audiences are watching around the world."],favorites:["Your favorites","Your personal collection of saved movies."],watchlist:["Your watchlist","A little list of stories for later."]};
  $("#page-title").textContent = titles[view]?.[0] || "Explore movies";
  $("#page-subtitle").textContent = titles[view]?.[1] || "";
  loadMovies(true);
  if (view !== "home") $("#discovery").scrollIntoView({behavior:"smooth", block:"start"});
}
async function tmdbFetch(path, params = {}) {
  const url = new URL(API_BASE + path);
  url.searchParams.set("api_key", TMDB_KEY);
  Object.entries(params).forEach(([key, value]) => { if (value !== "" && value != null) url.searchParams.set(key, String(value)); });
  const response = await fetch(url);
  if (!response.ok) throw new Error(`Movie service returned ${response.status}`);
  return response.json();
}
async function loadMovies(reset = false) {
  if (state.loading) return;
  if (reset) { state.page = 1; state.movies = []; }
  state.loading = true;
  const requestId = ++state.requestId;
  setStatus("Finding movies…");
  $("#load-more").hidden = true; $("#load-more-top").hidden = true;
  try {
    if (state.apiMode) {
      const params = {page:state.page, include_adult:false};
      if (state.view === "trending") {
        const data = await tmdbFetch("/trending/movie/week", {page:state.page});
        acceptResults(data, requestId); return;
      }
      if (state.view === "popular") {
        const data = await tmdbFetch("/movie/popular", {page:state.page});
        acceptResults(data, requestId); return;
      }
      if (state.search.trim()) {
        const data = await tmdbFetch("/search/movie", {...params, query:state.search.trim(), language:"en-US"});
        acceptResults(data, requestId); return;
      }
      if (state.view === "favorites" || state.view === "watchlist") {
        const ids = state.view === "favorites" ? state.favorites : state.watchlist;
        const existing = state.movies.filter(movie => ids.includes(Number(movie.id)));
        state.movies = existing;
        state.totalPages = 1;
        applyFiltersAndRender();
        return;
      }
      const discoverParams = {...params, sort_by: sortToApi(state.sort), with_original_language:state.language || undefined, with_genres:state.genre || undefined, primary_release_year:state.year || undefined, "vote_average.gte":state.rating || undefined};
      const data = await tmdbFetch("/discover/movie", discoverParams);
      acceptResults(data, requestId); return;
    } else {
      if (state.page === 1) state.movies = [...DEMO_MOVIES];
      state.totalPages = 1;
      applyFiltersAndRender();
    }
  } catch (error) {
    console.error("CineVerse movie loading error:", error);
    if (requestId === state.requestId) {
      state.apiMode = false; $("#mode-label").textContent = "Demo fallback";
      if (!state.movies.length) state.movies = [...DEMO_MOVIES];
      applyFiltersAndRender("Live movie data could not be loaded. Showing demo movies instead.");
    }
  } finally {
    if (requestId === state.requestId) state.loading = false;
  }
}
function sortToApi(sort) {
  return ({rating:"vote_average.desc",release:"primary_release_date.desc",title:"original_title.asc",popularity:"popularity.desc"})[sort] || "popularity.desc";
}
function acceptResults(data, requestId) {
  if (requestId !== state.requestId) return;
  const incoming = Array.isArray(data.results) ? data.results : [];
  state.movies = state.page > 1 ? [...state.movies, ...incoming] : incoming;
  state.totalPages = Math.min(Number(data.total_pages || 1), 500);
  applyFiltersAndRender();
}
function applyFiltersAndRender(note = "") {
  let movies = [...state.movies];
  if (state.view === "favorites") movies = movies.filter(movie => isFavorite(movie.id));
  if (state.view === "watchlist") movies = movies.filter(movie => isWatchlisted(movie.id));
  if (state.language) movies = movies.filter(movie => movie.original_language === state.language);
  if (state.genre) movies = movies.filter(movie => (movie.genre_ids || []).includes(Number(state.genre)));
  if (state.year) movies = movies.filter(movie => yearOf(movie) === state.year);
  if (Number(state.rating)) movies = movies.filter(movie => Number(movie.vote_average || 0) >= Number(state.rating));
  if (state.search.trim() && !state.apiMode) {
    const query = state.search.trim().toLowerCase();
    movies = movies.filter(movie => `${movie.title || ""} ${movie.original_title || ""}`.toLowerCase().includes(query));
  }
  movies.sort((a,b) => {
    if (state.sort === "rating") return Number(b.vote_average || 0) - Number(a.vote_average || 0);
    if (state.sort === "release") return (b.release_date || "").localeCompare(a.release_date || "");
    if (state.sort === "title") return (a.title || "").localeCompare(b.title || "");
    return Number(b.popularity || 0) - Number(a.popularity || 0);
  });
  state.filteredMovies = movies;
  renderMovies();
  updateCounts();
  const total = movies.length;
  $("#results-summary").textContent = `${total} movie${total === 1 ? "" : "s"} shown${state.apiMode && state.totalPages > 1 ? ` · page ${state.page} of ${state.totalPages}` : ""}`;
  if (note) setStatus(note);
  else if (!total) setStatus(state.view === "favorites" || state.view === "watchlist" ? "Nothing saved here yet. Browse movies and tap the heart or plus icon to save one." : "No movies match these filters. Try changing your search or filters.");
  else setStatus("");
  const canLoadMore = state.apiMode && state.page < state.totalPages && state.view !== "favorites" && state.view !== "watchlist";
  $("#load-more").hidden = !canLoadMore; $("#load-more-top").hidden = !canLoadMore;
}
function renderMovies() {
  grid.innerHTML = "";
  state.filteredMovies.forEach(movie => {
    const card = document.createElement("article");
    card.className = "movie-card"; card.tabIndex = 0; card.setAttribute("role","button");
    card.setAttribute("aria-label", `View details for ${movie.title || "movie"}`);
    const poster = posterUrl(movie.poster_path);
    const rating = Number(movie.vote_average || 0);
    const title = movie.title || movie.original_title || "Untitled movie";
    card.innerHTML = `
      <div class="poster-wrap">
        ${poster ? `<img src="${escapeHtml(poster)}" alt="Poster for ${escapeHtml(title)}" loading="lazy">` : `<div class="poster-placeholder"><b>CV</b><span>${escapeHtml(title)}</span></div>`}
        <span class="rating-pill"><span>★</span> ${rating ? rating.toFixed(1) : "—"}</span>
        <div class="card-actions">
          <button class="icon-button ${isFavorite(movie.id) ? "is-active" : ""}" data-action="favorite" aria-label="${isFavorite(movie.id) ? "Remove from" : "Add to"} favorites" title="Favorite">${isFavorite(movie.id) ? "♥" : "♡"}</button>
          <button class="icon-button ${isWatchlisted(movie.id) ? "is-active" : ""}" data-action="watchlist" aria-label="${isWatchlisted(movie.id) ? "Remove from" : "Add to"} watchlist" title="Watchlist">${isWatchlisted(movie.id) ? "✓" : "+"}</button>
        </div>
      </div>
      <div class="movie-info"><h3 class="movie-title" title="${escapeHtml(title)}">${escapeHtml(title)}</h3><div class="movie-subline"><span>${escapeHtml(yearOf(movie))}</span><span class="language-label">${escapeHtml(languageName(movie.original_language))}</span></div></div>`;
    card.addEventListener("click", event => {
      const actionButton = event.target.closest("[data-action]");
      if (actionButton) {
        event.stopPropagation();
        toggleCollection(actionButton.dataset.action, movie.id);
        renderMovies();
        return;
      }
      openDetails(movie);
    });
    card.addEventListener("keydown", event => { if (event.key === "Enter" || event.key === " ") { event.preventDefault(); openDetails(movie); } });
    const img = card.querySelector("img");
    if (img) img.addEventListener("error", () => { img.replaceWith(makePosterFallback(title)); }, {once:true});
    grid.append(card);
  });
}
function makePosterFallback(title) {
  const placeholder = document.createElement("div"); placeholder.className = "poster-placeholder";
  const mark = document.createElement("b"); mark.textContent = "CV";
  const name = document.createElement("span"); name.textContent = title;
  placeholder.append(mark,name); return placeholder;
}
function updateCounts() {
  $("#favorite-count").textContent = state.favorites.length;
  $("#watchlist-count").textContent = state.watchlist.length;
}
function toggleCollection(type, id) {
  const key = type === "favorite" ? "favorites" : "watchlist";
  const storageKey = type === "favorite" ? "cineverse-favorites" : "cineverse-watchlist";
  const list = state[key];
  const numberId = Number(id);
  const index = list.indexOf(numberId);
  if (index >= 0) { list.splice(index,1); showToast(type === "favorite" ? "Removed from favorites" : "Removed from watchlist"); }
  else { list.push(numberId); showToast(type === "favorite" ? "Added to favorites" : "Added to watchlist"); }
  saveStorage(storageKey, list); updateCounts();
  if (state.view === "favorites" || state.view === "watchlist") applyFiltersAndRender();
}
async function openDetails(movie) {
  state.selectedMovie = movie;
  let details = movie;
  if (state.apiMode && !movie.runtime) {
    try { details = await tmdbFetch(`/movie/${movie.id}`, {append_to_response:""}); state.selectedMovie = details; }
    catch (error) { console.warn("Could not load extended movie details:", error); }
  }
  const poster = posterUrl(details.poster_path);
  $("#modal-art").innerHTML = poster ? `<img src="${escapeHtml(poster)}" alt="Poster for ${escapeHtml(details.title || "movie")}">` : "";
  if (!poster) $("#modal-art").append(makePosterFallback(details.title || "Movie"));
  $("#modal-title").textContent = details.title || details.original_title || "Untitled movie";
  $("#modal-kicker").textContent = details.original_title && details.original_title !== details.title ? details.original_title : "MOVIE DETAILS";
  const meta = [yearOf(details), languageName(details.original_language), Number(details.vote_average) ? `★ ${Number(details.vote_average).toFixed(1)}/10` : "Rating unavailable", details.runtime ? `${details.runtime} min` : ""].filter(Boolean);
  $("#modal-meta").textContent = meta.join("  ·  ");
  $("#modal-overview").textContent = details.overview || "No synopsis is available for this title yet.";
  $("#modal-tags").innerHTML = genreNames(details.genres ? details.genres.map(g => g.id) : (details.genre_ids || [])).map(name => `<span>${escapeHtml(name)}</span>`).join("");
  $("#modal-favorite").textContent = isFavorite(details.id) ? "♥ Remove favorite" : "♡ Add to favorites";
  $("#modal-watchlist").textContent = isWatchlisted(details.id) ? "✓ Remove from watchlist" : "＋ Add to watchlist";
  $("#modal-source").textContent = state.apiMode ? "Movie information provided by TMDB." : "Demo entry for project preview; details are illustrative.";
  modal.hidden = false; document.body.style.overflow = "hidden"; $("#modal-close").focus();
}
function closeModal() { modal.hidden = true; document.body.style.overflow = ""; state.selectedMovie = null; }
function applyFiltersFromControls() {
  state.language = $("#language-filter").value; state.genre = $("#genre-filter").value;
  state.year = $("#year-filter").value; state.rating = Number($("#rating-filter").value);
  state.sort = $("#sort-filter").value; state.page = 1;
  syncFilterControls(); loadMovies(true);
}
function debounce(fn, delay) {
  let timer; return (...args) => { clearTimeout(timer); timer = setTimeout(() => fn(...args), delay); };
}
const searchChanged = debounce(() => {
  state.search = $("#search-input").value.trim(); state.page = 1;
  $("#clear-search").hidden = !state.search;
  loadMovies(true);
}, 320);

function wireEvents() {
  document.querySelectorAll(".nav-link").forEach(button => button.addEventListener("click", () => {
    document.querySelector(".main-nav").classList.remove("open");
    $("#mobile-menu").setAttribute("aria-expanded", "false");
    setView(button.dataset.view);
  }));
  $("#mobile-menu").addEventListener("click", () => {
    const nav = document.querySelector(".main-nav"); const open = nav.classList.toggle("open");
    $("#mobile-menu").setAttribute("aria-expanded", String(open));
  });
  $("#language-filter").addEventListener("change", applyFiltersFromControls);
  $("#genre-filter").addEventListener("change", applyFiltersFromControls);
  $("#year-filter").addEventListener("change", applyFiltersFromControls);
  $("#rating-filter").addEventListener("change", applyFiltersFromControls);
  $("#sort-filter").addEventListener("change", applyFiltersFromControls);
  $("#search-input").addEventListener("input", searchChanged);
  $("#clear-search").addEventListener("click", () => { $("#search-input").value = ""; state.search = ""; $("#clear-search").hidden = true; loadMovies(true); });
  $("#reset-filters").addEventListener("click", () => {
    state.language = ""; state.genre = ""; state.year = ""; state.rating = 0; state.sort = "popularity"; state.search = "";
    syncFilterControls(); loadMovies(true);
  });
  document.querySelectorAll(".language-chip").forEach(chip => chip.addEventListener("click", () => {
    state.language = chip.dataset.language || ""; state.page = 1; syncFilterControls(); loadMovies(true);
    $("#discovery").scrollIntoView({behavior:"smooth",block:"start"});
  }));
  $("#explore-button").addEventListener("click", () => { setView("all"); $("#discovery").scrollIntoView({behavior:"smooth",block:"start"}); });
  $("#hero-trending").addEventListener("click", () => setView("trending"));
  $("#load-more").addEventListener("click", () => { if (!state.loading && state.page < state.totalPages) { state.page += 1; loadMovies(false); } });
  $("#load-more-top").addEventListener("click", () => $("#load-more").click());
  $("#modal-close").addEventListener("click", closeModal);
  modal.addEventListener("click", event => { if (event.target === modal) closeModal(); });
  document.addEventListener("keydown", event => { if (event.key === "Escape" && !modal.hidden) closeModal(); });
  $("#modal-favorite").addEventListener("click", () => {
    if (!state.selectedMovie) return;
    toggleCollection("favorite", state.selectedMovie.id);
    $("#modal-favorite").textContent = isFavorite(state.selectedMovie.id) ? "♥ Remove favorite" : "♡ Add to favorites";
    renderMovies();
  });
  $("#modal-watchlist").addEventListener("click", () => {
    if (!state.selectedMovie) return;
    toggleCollection("watchlist", state.selectedMovie.id);
    $("#modal-watchlist").textContent = isWatchlisted(state.selectedMovie.id) ? "✓ Remove from watchlist" : "＋ Add to watchlist";
    renderMovies();
  });
}
function init() {
  initFilters(); wireEvents(); syncFilterControls(); updateCounts();
  if (state.apiMode) $("#mode-label").textContent = "Live TMDB data";
  loadMovies(true);
}
document.addEventListener("DOMContentLoaded", init);
